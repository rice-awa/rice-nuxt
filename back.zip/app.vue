<template>
	<div class="min-h-screen">
		<!-- Banner背景 -->
		<div class="fixed top-0 left-0 right-0 h-screen pointer-events-none">
			<div
				class="h-full bg-gradient-to-b from-white via-[#5382DB]/40 to-[#5382DB]/30 dark:from-gray-900 dark:via-[#5382DB]/30 dark:to-transparent"
			></div>
		</div>

		<!-- 内容容器 -->
		<div class="relative z-10">
			<!-- 导航栏 -->
			<nav
				class="fixed w-full z-50 bg-white/80 backdrop-blur-md border-b border-gray-200 dark:bg-gray-800/80 dark:border-gray-700"
			>
				<div class="container mx-auto px-6">
					<div class="flex justify-between items-center h-16">
						<!-- Logo -->
						<div class="flex items-center">
							<h1 class="text-2xl font-bold bg-gradient-to-r from-blue-500 to-purple-600 bg-clip-text text-transparent">
								全栈<span class="font-extrabold">FULLSTACK</span>
							</h1>
						</div>

						<!-- 导航链接 -->
						<div class="hidden md:flex items-center space-x-8">
							<NuxtLink
								v-for="(link, index) in navLinks"
								:key="index"
								:to="link.href"
								class="text-gray-600 hover:text-blue-500 transition-all duration-300 text-sm font-medium nav-link dark:text-gray-300 dark:hover:text-blue-400"
								@click.prevent="scrollToSection(link.href)"
							>
								{{ link.text }}
							</NuxtLink>

							<!-- 主题切换按钮 -->
							<button
								@click="toggleDarkMode"
								class="p-2 rounded-lg bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors duration-200"
							>
								<svg v-if="isDarkMode" class="w-5 h-5 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
									<path
										fill-rule="evenodd"
										d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z"
										clip-rule="evenodd"
									/>
								</svg>
								<svg v-else class="w-5 h-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20">
									<path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z" />
								</svg>
							</button>
						</div>
					</div>
				</div>
			</nav>

			<!-- 移动端菜单按钮 -->
			<div class="md:hidden fixed top-4 right-4 z-50">
				<button class="p-2 bg-gray-100 rounded-lg dark:bg-gray-800" @click="isMobileMenuOpen = !isMobileMenuOpen">
					<svg class="w-6 h-6 text-gray-600 dark:text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path
							v-if="!isMobileMenuOpen"
							stroke-linecap="round"
							stroke-linejoin="round"
							stroke-width="2"
							d="M4 6h16M4 12h16m-16 6h16"
						/>
						<path v-else stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
					</svg>
				</button>
			</div>

			<!-- 移动端导航菜单 -->
			<Transition
				enter-active-class="transition duration-200 ease-out"
				enter-from-class="transform translate-x-full opacity-0"
				enter-to-class="transform translate-x-0 opacity-100"
				leave-active-class="transition duration-200 ease-in"
				leave-from-class="transform translate-x-0 opacity-100"
				leave-to-class="transform translate-x-full opacity-0"
			>
				<div
					v-if="isMobileMenuOpen"
					class="md:hidden fixed inset-y-0 right-0 z-40 w-64 bg-white dark:bg-gray-900 pt-20 shadow-lg"
				>
					<div class="px-6">
						<div class="flex flex-col space-y-6">
							<NuxtLink
								v-for="(link, index) in navLinks"
								:key="index"
								:to="link.href"
								class="text-lg font-medium text-gray-900 dark:text-gray-100 hover:text-blue-500 dark:hover:text-blue-400"
								@click="handleMobileNavClick(link.href)"
							>
								{{ link.text }}
							</NuxtLink>

							<!-- 移动端主题切换按钮 -->
							<button
								@click="toggleDarkMode"
								class="flex items-center space-x-2 text-lg font-medium text-gray-900 dark:text-gray-100"
							>
								<span>{{ isDarkMode ? "浅色模式" : "深色模式" }}</span>
								<div class="p-2 rounded-lg bg-gray-100 dark:bg-gray-800">
									<svg v-if="isDarkMode" class="w-5 h-5 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
										<path
											fill-rule="evenodd"
											d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z"
											clip-rule="evenodd"
										/>
									</svg>
									<svg v-else class="w-5 h-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20">
										<path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z" />
									</svg>
								</div>
							</button>
						</div>
					</div>
				</div>
			</Transition>

			<!-- Banner部分 -->
			<section class="h-screen flex items-center justify-center relative">
				<div class="container mx-auto px-6 text-center">
					<h2 ref="titleRef" class="text-6xl md:text-7xl font-bold mb-6 drop-shadow-sm flex flex-col gap-4">
						<div class="flex justify-center">
							<span
								v-for="(char, index) in titleLines.line1"
								:key="`line1-${index}`"
								class="line1-char inline-block bg-clip-text text-transparent bg-gradient-to-br from-blue-600 via-blue-500 to-purple-600 dark:from-blue-400 dark:via-blue-300 dark:to-purple-400 hover:bounce"
								>{{ char }}</span
							>
						</div>
						<div class="flex justify-center">
							<span
								v-for="(char, index) in titleLines.line2"
								:key="`line2-${index}`"
								class="line2-char inline-block bg-clip-text text-transparent bg-gradient-to-br from-blue-600 via-blue-500 to-purple-600 dark:from-blue-400 dark:via-blue-300 dark:to-purple-400 hover:bounce"
								>{{ char }}</span
							>
						</div>
					</h2>
					<p class="text-xl text-gray-700 mb-8 max-w-2xl mx-auto dark:text-gray-200">创新 · 协作 · 未来</p>
					<button
						class="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-3 rounded-full transition-all transform hover:scale-105 shadow-lg"
					>
						加入我们
					</button>
				</div>
			</section>

			<!-- 其他内容区域 - 使用白色背景 -->
			<div class="relative bg-white dark:bg-gray-900">
				<section id="features" class="py-20">
					<div class="container mx-auto px-6 grid md:grid-cols-4 gap-8">
						<div
							v-for="(feature, index) in features"
							:key="index"
							class="p-8 bg-white rounded-xl hover:shadow-xl transition-all border border-gray-100 dark:bg-gray-800 dark:border-gray-700"
						>
							<div class="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mb-6">
								<Icon :name="feature.icon" class="w-8 h-8 text-blue-500" />
							</div>
							<h3 class="text-xl font-semibold mb-4 text-gray-900 dark:text-gray-300">{{ feature.title }}</h3>
							<p class="text-gray-600 dark:text-gray-400">{{ feature.desc }}</p>
						</div>
					</div>
				</section>

				<!-- 近期活动 -->
				<section id="activities" class="py-20 bg-gray-50 dark:bg-gray-900">
					<div class="container mx-auto px-6">
						<h2 class="text-4xl font-bold mb-12 text-center text-gray-900 dark:text-gray-300">近期活动</h2>
						<div class="grid lg:grid-cols-3 gap-8">
							<div
								v-for="activity in activities"
								:key="activity.title"
								class="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all dark:bg-gray-800"
							>
								<div class="w-full h-48 bg-blue-100 rounded-lg mb-6 overflow-hidden">
									<img :src="activity.image" :alt="activity.title" class="w-full h-full object-cover" />
								</div>
								<h3 class="text-2xl font-bold mb-2 text-gray-900 dark:text-gray-300">{{ activity.title }}</h3>
								<p class="text-gray-600 mb-4 dark:text-gray-400">{{ activity.desc }}</p>
								<p class="text-blue-500">{{ activity.date }}</p>
							</div>
						</div>
					</div>
				</section>

				<!-- 发展历程 -->
				<section id="timeline" class="py-20">
					<div class="container mx-auto px-6">
						<h2 class="text-4xl font-bold mb-12 text-center text-gray-900 dark:text-gray-300">发展历程</h2>
						<div class="space-y-8">
							<div v-for="item in timeline" :key="item.year" class="flex items-center gap-8 group">
								<div class="text-3xl font-bold text-blue-500 w-24">{{ item.year }}</div>
								<div
									class="flex-1 p-6 bg-white rounded-xl shadow-lg group-hover:shadow-xl transition-all dark:bg-gray-800"
								>
									<h3 class="text-xl font-bold mb-2 text-gray-900 dark:text-gray-300">{{ item.title }}</h3>
									<p class="text-gray-600 dark:text-gray-400">{{ item.desc }}</p>
								</div>
							</div>
						</div>
					</div>
				</section>

				<!-- 加入我们 -->
				<section id="join" class="py-32 text-center bg-gray-50 dark:bg-gray-900">
					<div class="container mx-auto px-6">
						<h2 class="text-4xl font-bold mb-8 text-gray-900 dark:text-gray-300">加入全栈信息处理协会</h2>
						<p class="text-xl text-gray-600 mb-12 max-w-2xl mx-auto dark:text-gray-400">
							加入我们，一起探索技术的无限可能
						</p>
						<button
							class="bg-blue-500 hover:bg-blue-600 text-white px-12 py-4 rounded-full text-lg transition-all transform hover:scale-105 shadow-xl"
						>
							立即加入
						</button>
					</div>
				</section>

				<!-- 页脚 -->
				<footer class="bg-gray-900 text-gray-400 py-12">
					<div class="container mx-auto px-4">
						<div class="grid grid-cols-1 md:grid-cols-3 gap-8">
							<!-- 资源 -->
							<div>
								<h3 class="text-white text-lg font-semibold mb-4">资源</h3>
								<ul class="space-y-2">
									<li><NuxtLink to="/support" class="hover:text-white">支持</NuxtLink></li>
									<li><NuxtLink to="/blog" class="hover:text-white">博客</NuxtLink></li>
									<li><NuxtLink to="/security" class="hover:text-white">安全</NuxtLink></li>
								</ul>
							</div>

							<!-- 开发人员 -->
							<div>
								<h3 class="text-white text-lg font-semibold mb-4">开发人员</h3>
								<ul class="space-y-2">
									<li><NuxtLink to="/api" class="hover:text-white">API 文档</NuxtLink></li>
									<li><NuxtLink to="/teams-api" class="hover:text-white">Teams API</NuxtLink></li>
									<li><NuxtLink to="/docs" class="hover:text-white">开发指南</NuxtLink></li>
								</ul>
							</div>

							<!-- 关于 -->
							<div>
								<h3 class="text-white text-lg font-semibold mb-4">关于</h3>
								<ul class="space-y-2">
									<li><NuxtLink to="/about" class="hover:text-white">关于我们</NuxtLink></li>
								</ul>
							</div>
						</div>

						<div class="mt-8 pt-8 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center">
							<div class="text-sm">© 2024 全栈信息处理协会. 保留所有权利.</div>
							<div class="flex space-x-6 mt-4 md:mt-0">
								<a href="#" class="text-gray-400 hover:text-white">
									<span class="sr-only">Facebook</span>
									<i class="fab fa-facebook"></i>
								</a>
								<a href="#" class="text-gray-400 hover:text-white">
									<span class="sr-only">Twitter</span>
									<i class="fab fa-twitter"></i>
								</a>
								<a href="#" class="text-gray-400 hover:text-white">
									<span class="sr-only">GitHub</span>
									<i class="fab fa-github"></i>
								</a>
							</div>
						</div>
					</div>
				</footer>
			</div>
		</div>
	</div>
</template>

<script setup>
import { ref, watch, onMounted } from "vue";
import gsap from "gsap";

const isDarkMode = ref(false);
const isMobileMenuOpen = ref(false);

const handleMobileNavClick = (href) => {
	scrollToSection(href);
	isMobileMenuOpen.value = false;
};

onMounted(() => {
	const savedTheme = localStorage.getItem("theme");
	if (savedTheme) {
		isDarkMode.value = savedTheme === "dark";
		updateTheme();
	} else {
		const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
		isDarkMode.value = prefersDark;
		updateTheme();
	}

	window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", (e) => {
		isDarkMode.value = e.matches;
		updateTheme();
	});

	const ctx = gsap.context(() => {
		const chars = titleRef.value.querySelectorAll("span");

		gsap.set(chars, {
			opacity: 0,
			y: 40,
		});

		const tl = gsap.timeline();

		const line1Chars = titleRef.value.querySelectorAll(".line1-char");
		tl.to(line1Chars, {
			duration: 0.8,
			opacity: 1,
			y: 0,
			stagger: 0.1,
			ease: "power2.out",
		})
			.to(
				titleRef.value.querySelectorAll(".line2-char"),
				{
					duration: 0.6,
					opacity: 1,
					y: 0,
					stagger: 0.05,
					ease: "power2.out",
				},
				"-=0.5"
			)
			.to(
				chars,
				{
					duration: 0.6,
					y: "+=20",
					ease: "elastic.out(1, 0.4)",
					stagger: {
						amount: 0.5,
						from: "random",
					},
				},
				"+=0.4"
			);
	}, titleRef);

	window.addEventListener("scroll", () => {
		if (isMobileMenuOpen.value) {
			isMobileMenuOpen.value = false;
		}
	});

	watch(isMobileMenuOpen, (isOpen) => {
		if (isOpen) {
			document.body.classList.add("overflow-hidden");
		} else {
			document.body.classList.remove("overflow-hidden");
		}
	});

	return () => ctx.revert();
});

const updateTheme = () => {
	if (isDarkMode.value) {
		document.documentElement.classList.add("dark");
		localStorage.setItem("theme", "dark");
	} else {
		document.documentElement.classList.remove("dark");
		localStorage.setItem("theme", "light");
	}
};

const toggleDarkMode = () => {
	isDarkMode.value = !isDarkMode.value;
	updateTheme();
};

const navLinks = [
	{ text: "社团特色", href: "#features" },
	{ text: "近期活动", href: "#activities" },
	{ text: "发展历程", href: "#timeline" },
	{ text: "加入我们", href: "#join" },
];

const features = [
	{
		icon: "ph:code-bold",
		title: "前沿技术",
		desc: "掌握最新开发工具与框架",
	},
	{
		icon: "ph:lightbulb-bold",
		title: "创新项目",
		desc: "参与多个创新项目的开发",
	},
	{
		icon: "ph:users-bold",
		title: "团队合作",
		desc: "与团队成员合作完成项目",
	},
	{
		icon: "ph:graduation-cap-bold",
		title: "实践经验",
		desc: "获得实践经验和技能提升",
	},
];

const activities = [
	{
		title: "黑客马拉松",
		desc: "48小时极限编程挑战，展现创意与技术的完美融合",
		date: "2024年3月15日",
		image: "/images/hackathon.jpg",
	},
	{
		title: "技术讲座",
		desc: "业界大牛分享前沿技术与发展趋势",
		date: "2024年3月20日",
		image: "/images/tech-talk.jpg",
	},
	{
		title: "项目实战",
		desc: "真实项目开发体验，提升实战能力",
		date: "2024年4月1日",
		image: "/images/project.jpg",
	},
];

const timeline = [
	{
		year: "2023",
		title: "全国科技创新大赛金奖",
		desc: "团队开发的智能校园项目获得全国大赛金奖",
	},
	{
		year: "2022",
		title: "首届黑客马拉松",
		desc: "成功举办校园首届黑客马拉松大赛",
	},
	{
		year: "2021",
		title: "社团成立",
		desc: "全栈信息技术社正式成立，开启技术探索之旅",
	},
];

const scrollToSection = (href) => {
	const el = document.querySelector(href);
	if (el) {
		el.scrollIntoView({ behavior: "smooth" });
	}
};

const titleRef = ref(null);

const titleLines = {
	line1: "探索数字宇宙".split(""),
	line2: "FULLSTACK".split(""),
};
</script>

<style>
/* 自定义动画 */
@keyframes fade-in-up {
	0% {
		opacity: 0;
		transform: translateY(20px);
	}
	100% {
		opacity: 1;
		transform: translateY(0);
	}
}

.animate-fade-in-up {
	animation: fade-in-up 1s ease-out forwards;
}

.backdrop-blur-md {
	-webkit-backdrop-filter: blur(12px);
	backdrop-filter: blur(12px);
}

.nav-link {
	position: relative;
	padding: 0.5rem 0;
}

.nav-link::after {
	content: "";
	position: absolute;
	bottom: -2px;
	left: 0;
	width: 0;
	height: 2px;
	@apply bg-gradient-to-r from-blue-500 to-purple-600;
	transition: width 0.3s ease;
}

.nav-link:hover::after {
	width: 100%;
}

h1,
h2,
h3,
p {
	text-shadow: none;
}

button {
	font-weight: 500;
	letter-spacing: 0.025em;
}

@media (max-width: 768px) {
	.container {
		padding-left: 1rem;
		padding-right: 1rem;
	}

	h1 {
		font-size: clamp(1.5rem, 10vw, 5rem);
	}

	.nav-link {
		padding: 0.75rem 0;
	}
}

.fade-enter-active,
.fade-leave-active {
	transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
	opacity: 0;
}

html {
	scroll-behavior: smooth;
	scroll-padding-top: 80px;
}

.dark text-gray-300 {
	color: rgba(209, 213, 219, var(--tw-text-opacity));
}

:root {
	transition: background-color 0.5s ease, color 0.5s ease, border-color 0.5s ease;
}

*,
::before,
::after {
	transition: background-color 0.5s ease, border-color 0.5s ease, color 0.5s ease, opacity 0.5s ease,
		transform 0.5s ease;
}

.from-gray-50,
.to-white,
.dark\:from-gray-900,
.dark\:to-black {
	transition: background-image 0.5s ease;
}

.transition-none,
.transition-none::before,
.transition-none::after {
	transition: none !important;
}

nav {
	transition: background-color 0.5s ease, backdrop-filter 0.5s ease, border-color 0.5s ease;
}

.bg-white,
.dark\:bg-gray-800,
.bg-gray-50,
.dark\:bg-gray-900 {
	transition: background-color 0.5s ease, border-color 0.5s ease, box-shadow 0.5s ease;
}

.inline-block {
	display: inline-block;
	overflow: hidden;
}

@keyframes bounce {
	0% {
		transform: translateY(0);
	}
	100% {
		transform: translateY(-10px);
	}
}

@keyframes fall {
	0% {
		transform: translateY(-10px);
	}
	100% {
		transform: translateY(0);
	}
}

.h2-span-hover {
	animation: bounce 0.5s cubic-bezier(0.4, 0, 0.2, 1) forwards;
}

.h2-span-leave {
	animation: fall 0.5s cubic-bezier(0.4, 0, 0.2, 1) forwards;
}

.h2-span-hover:hover {
	animation: none;
}

/* 添加到现有的 style 标签中 */
h2 span {
	display: inline-block;
	cursor: default;
}

.h2-span-hover,
.h2-span-leave {
	display: inline-block;
	cursor: default;
}

h2 span {
	animation: bounce 0.5s cubic-bezier(0.4, 0, 0.2, 1) forwards;
}

h2 span:hover {
	animation: fall 0.5s cubic-bezier(0.4, 0, 0.2, 1) forwards;
}

h2 span:active {
	animation: none;
}

/* 为标题字符添加悬停效果 */
h2 span {
	display: inline-block;
	cursor: default;
}

.h2-span-hover,
.h2-span-leave {
	display: inline-block;
	cursor: default;
}

h2 span:hover {
	animation: bounce 0.5s cubic-bezier(0.4, 0, 0.2, 1) forwards;
}

h2 span:not(:hover) {
	animation: fall 0.5s cubic-bezier(0.4, 0, 0.2, 1) forwards;
}
</style>
